// Global and Local Variable let or const mein hai 

//let age = 18;

//if(age > 19){
//  console.log(age);
//}
//else{
//    console.log(`You are not eligible = ` + age)
//}

// module

// let bike = {
//     name: "Suzuki 150" ,
//     model: 2024  ,
//     type: "new"
// }

// let Buyer = `I want to buy a bike "${bike.name}" and his model is ${bike.model} and I want to buy the ${bike.type} one`;

// console.log(Buyer)


// import inquirer from "inquirer"

// let answer = inquirer.prompt(
//     {
//         name: "Q1" ,
//         message: "What is your name ?\n" , 
//         type: "input"
//     }
// )

// console.log(`Hello ${answer.Q1} kaise ho`)

import inquirer from "inquirer"

let answer = await inquirer.prompt(
  [  
    {
        name: "q1" , 
        message: "What is your name ?" , 
        type: "input"
    },
    {
        name: "q2" , 
        message: "What is your Father name ?" , 
        type: "input"
    }
  ]
)

console.log(`Hello ${answer.q1}, Your Father name is ${answer.q2}`)
