import inquirer from "inquirer";

let answer = await inquirer.prompt(
    {
        name: "q1" , 
        message: "Insert a number \n",
        type: "input"
    }
)
if(answer.q1 = 100){
    console.log(answer.q1+4+3+2+1)
}
